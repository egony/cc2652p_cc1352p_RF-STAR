﻿2021-02-10

Zigbee Coordinator Firmware for RF-STAR RF-BM-2652P2 module (cc2652p chip)

Based on Koenkk patches for Z-Stack_3.x.0.
https://github.com/Koenkk/Z-Stack-firmware/blob/master/coordinator/Z-Stack_3.x.0/firmware.patch

SDK 4.40.00.44

Built for CC2652P1F chip variant (not for CC1352P1F).

Default TX power: 20dBm. Power can be adjusted in zigbee2mqtt config:

experimental:
  transmit_power: 5

Available TX power values: -20, -18, -15, -12, -10, -9, -6, -5, -3, 0, 1..5, 14..20

LEDs description:
  Green (DIO7) turns ON when High-power PA is not used (TX power from -20 to 5 dBm)
  Red (DIO6) turns ON when High-power PA is used (TX power from 15 to 20 dBm)
  Leds CAN NOT be turned OFF by zigbee2mqtt config - sorry, I still haven't skills for it.

Buttons description:
  Flash button on DIO15 used for bootloader activation (for firmware update)
  Reset button - you guess what it do.

NOTES:

Coordinator backup from 2538/2652/1352 can be loaded back into another 2538/2652/1352, but into CLEAN (never used with zigbee2mqtt) chip only.
You can clear chip with zigbee2mqtt script scripts\zStackEraseAllNvMem.js

FIRMWARE SOURCES:

As I know, sharing source codes prohibited by TI, so there is no sources here. And I can't made patches because they will include code. But you now what to do ;)